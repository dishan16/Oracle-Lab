import React from 'react';
import logo from './logo.svg';
import './App.css';
import Web3 from 'web3';
import { STOCK_ORACLE_ABI, STOCK_ORACLE_ADDRESS } from './quotecontract';
import TextField from '@material-ui/core/TextField';

function App() {
  const web3 = new Web3("http://localhost:7545")
  const accounts = async () =>{
    await web3.eth.getAccounts()
  }   
  console.log("Account 0 = ", accounts[0] )
  
  const stockQuote = new web3.eth.Contract(STOCK_ORACLE_ABI, STOCK_ORACLE_ADDRESS)
      
  var retval = async() => {await stockQuote.methods.getStockPrice(web3.utils.fromAscii("AAAA")).call();}
  console.log(retval);

  return (
    <form noValidate autoComplete="off">
    <TextField id="Stock Symbol" label="Stock Symbol" />
  </form>
  );
}

export default App;
